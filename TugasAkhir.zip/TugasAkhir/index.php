<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Morrah Farm | Our Farm in Your Hand</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;600;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
	
	<!-- Navbar Start -->
    <nav class="navbar navbar-expand-md bg-light navbar-light sticky-top p-0">
        <a href="index.php" class="navbar-brand d-flex align-items-center border-end px-4 px-lg-5">
             <img src="img/logo.jpg" alt="logo" width="50" height="50" class="d-inline-block align-text-top">
            <h2 class="m-3 text-primary">Morrah Farm</h2>
        </a>
        <button type="button" class="navbar-toggler me-3" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="index.php" class="nav-item nav-link active fw-medium">Home</a>
                <a href="#section1" class="nav-item nav-link fw-medium">About</a>
                <a href="#section2" class="nav-item nav-link fw-medium">Product</a>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle fw-medium"  data-bs-toggle="dropdown">More</a>
                    <div class="dropdown-menu bg-light m-0">
                        <a href="#section3" class="dropdown-item">Testimonial</a>
                        <a href="#section4" class="dropdown-item">Our Team</a>
                    </div>
                </div>
                <a href="#footer" class="nav-item nav-link">Contact</a>
            </div>
            <a href="https://wa.me/6282279666651?text=Hai%20Admin!%20Saya%20ingin%20belanja%20produk%20ini!" class="btn btn-primary rounded-0 py-4 px-lg-4 d-flex d-lg-block">
            <div class="icons"> 
            	<div class="fas fa-shopping-cart" id="card-btn">
                </div>
            </div>
            </a>
        </div>
    </nav>
    <!-- Navbar End -->

 <!-- Carousel Start -->
    <div class="container-fluid p-0 pb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="owl-carousel header-carousel position-relative">
            <div class="owl-carousel-item position-relative" data-dot="<img src='img/carousel-3.jpg'>">
                <img class="img-fluid" src="img/carousel-3.jpg" alt="">
                <div class="owl-carousel-inner">
                    <div class="container">
                        <div class="row justify-content-start">
                            <div class="col-18 col-lg-10">
                                <h1 class="display-2 text-white animated slideInDown" style="text-shadow: 1px 2px 3px #666666; ">Pengembangan Subsistem Agribisnis Budidaya</h1>
                                <p class="fs-5 fw-medium text-white mb-4 pb-3" style="text-shadow: 2px 2px 3px #000000;">Kegiatan Budidaya hewan ternak untuk menghasilkan hasil olahan ternak yang memiliki daya guna untuk masyarakat luas</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="owl-carousel-item position-relative" data-dot="<img src='img/carousel-2.jpg'>">
                <img class="img-fluid" src="img/carousel-2.jpg" alt="">
                <div class="owl-carousel-inner">
                    <div class="container">
                        <div class="row justify-content-start">
                            <div class="col-10 col-lg-8">
                                <h1 class="display-2 text-white animated slideInDown" style="text-shadow: 2px 2px 3px #666666; ">Perngembangan Subsistem Jasa Penunjang</h1>
                                <p class="fs-5 fw-medium text-white mb-4 pb-3" style="text-shadow: 2px 2px 3px #000000;">Menyediakan jasa penunjang yang dibutuhkan oleh subsistem agribisnis lainnya, seperti transportasi, penyuluhan, pendidikan, penelitian dan pengembangan.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="owl-carousel-item position-relative" data-dot="<img src='img/carousel-1.jpg''>">
                <img class="img-fluid" src="img/carousel-1.jpg" alt="">
                <div class="owl-carousel-inner">
                    <div class="container">
                        <div class="row justify-content-start">
                            <div class="col-10 col-lg-8">
                                <h1 class="display-2 text-white animated slideInDown" style="text-shadow: 2px 2px 3px #666666; ">Pengembangan Organisasi dan Manajemen</h1>
                                <p class="fs-5 fw-medium text-white mb-4 pb-3" style="text-shadow: 2px 2px 3px #000000;">Mengembangkan organisasi yang sehat serta manajemen yang baik dan transparan sebagai bagian mutlak menuju peternakan yang berorientasi pada agribisnis dan berdaya saing.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Carousel End -->


    <!-- Feature Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.2s">
                    <div class="d-flex align-items-center mb-4">
                        <div class="btn-lg-square bg-primary rounded-circle me-3">
                            <i class="fa fa-users text-white"></i>
                        </div>
                        <h1 class="mb-0" data-toggle="counter-up">489</h1>
                    </div>
                    <h5 class="mb-3">Happy Customers</h5>
                    <span>Kunjungan dan pertanyaan yang masuk seputar Morrah Farm dan Produk Olahannya</span>
                </div>
                <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.4s">
                    <div class="d-flex align-items-center mb-4">
                        <div class="btn-lg-square bg-primary rounded-circle me-3">
                            <i class="fa fa-car text-white"></i>
                        </div>
                        <h1 class="mb-0" data-toggle="counter-up">1000</h1>
                    </div>
                    <h5 class="mb-3">Produk Terjual</h5>
                    <span>Lebih dari 100 produk olahan terjual ke penjuru Tapanuli Utara setiap harinya</span>
                </div>
                <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.6s">
                    <div class="d-flex align-items-center mb-4">
                        <div class="btn-lg-square bg-primary rounded-circle me-3">
                            <i class="fa fa-award text-white"></i>
                        </div>
                        <h1 class="mb-0" data-toggle="counter-up">1719</h1>
                    </div>
                    <h5 class="mb-3">Diakui</h5>
                    <span>Produk Morrah Farm Sudah diakui oleh lebih dari ribuan orang dan mitra </span>
                </div>
                <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.7s">
                    <div class="d-flex align-items-center mb-4">
                        <div class="btn-lg-square bg-primary rounded-circle me-3">
                            <i class="fa fa-users-cog text-white"></i>
                        </div>
                        <h1 class="mb-0" data-toggle="counter-up">63</h1>
                    </div>
                    <h5 class="mb-3">Puluhan Pekerja</h5>
                    <span>Mempekerjakan puluhan pekerja demi mengurangi angka pengangguran</span>
                </div>
            </div>
        </div>
    </div>
    <!-- Feature Start -->


    <!-- About Start -->
    <div class="container-fluid bg-light overflow-hidden my-5 px-lg-0" id="section1">
        <div class="container about px-lg-0">
            <div class="row g-0 mx-lg-0">
                <div class="col-lg-6 ps-lg-0 wow fadeIn" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="position-absolute img-fluid w-80 h-100" src="img/about.jpg" style="object-fit: cover;" alt="">
                    </div>
                </div>
                <div class="col-lg-6 about-text py-5 wow fadeIn" data-wow-delay="0.5s">
                    <div class="p-lg-7 pe-lg-0">
                        <h6 class="text-primary">About Us</h6>
                        <h1 class="mb-4" >Morrah Farm - Koperasi Guna Satwa Mandiri</h1>
                        <p>Morrah Farm merupakan salah satu bidang usaha dari Koperasi Produsen Guna Satwa Mandiri (GSM) yang bergerak di bidang Peternakan Kerbau Perah, didirikan pada bulan Juni tahun 2020 dengan lokasi peternakan di Desa Bahal Batu Kecamatan Siborong-borong Kabupaten Tapanuli Utara Provinsi Sumatera Utara.</p>
                        </br>
                        <h1 class="mb-4" style="text-align:center;">Visi dan Misi Morrah Farm</h1>
                        <h6 class="text-primary" style="text-align: center;">Visi</h6>
                        <p style="text-align: center;">Menjadi Peternakan Kerbau Perah Berorientasi Agribisnis yang Berdaya Saing dan mampu melestarikan Plasma Nutfah dan budaya bangsa</p>
                        <h6 class="text-primary" style="text-align: center;">Misi</h6>
                        <p style="text-align:center;"><i class="fa fa-check-circle text-primary me-3"></i>Melaksanakan Usaha Peternakan yang berorientasi Agribisnis</p>
                        <p style="text-align:center;"><i class="fa fa-check-circle text-primary me-3"></i> Mengembangkan ilmu pengetahuan dan teknologi yang mutunya dapat bersaing secara nasional dan internasional</p>
                        <p style="text-align:center;"><i class="fa fa-check-circle text-primary me-3"></i> Melestarikan Kerbau perah sebagai plasma nutfah</p>
                        <p style="text-align:center;"><i class="fa fa-check-circle text-primary me-3"></i>  Melaksanakan Pendidikan dan Pelatihan (Diklat) kerbau perah guna meningkatkan kesejahteraan masyarakat</p>
                        <p style="text-align:center;"><i class="fa fa-check-circle text-primary me-3"></i>Melestarikan sumberdaya alam dan lingkungan serta budaya bangsa</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


    <!-- Product Start -->
    <div class="container-xxl py-5" id="section2">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <h6 class="text-primary">Our Product</h6>
                <h1 class="mb-4">Hasil Olahan Produk-Produk Morrah Farm</h1>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item rounded overflow-hidden">
                        <img class="img-fluid" src="img/susu.jpeg" alt="">
                        <div class="position-relative p-4 pt-0">
                            <h4 class="mb-3 mt-3">Susu Non Pasteurisasi</h4>
                            <p>Susu Asli yang langsung diperoleh dari pemerahan Kerbau pilihan untuk memperoleh kualitas terbaik</p>
                            <p style="font-weight: 700; margin-bottom: 2px;">Rp 25.000 / L</p>
                            <i class="fa fa-shopping-cart ms-2"></i>
                            <a class="small fw-medium" href="https://wa.me/6282279666651?text=Hai!%20Saya%20ingin%20memesan%20produk%20ini!">Beli Sekarang</a>
                        </div>
                    </div>
                </div>
               <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item rounded overflow-hidden">
                        <img class="rounded img-fluid" src="img/susuori.jpg" alt="">
                        <div class="position-relative p-4 pt-0">
                            <h4 class="mb-3 mt-3">Susu Original</h4>
                            <p>Susu segar yang sudah mengalami pengolahan pasteurisasi dengan kualitas terbaik</p>
                            <p style="font-weight: 700; margin-bottom: 2px;">Rp 32.000 / L</p>
                            <i class="fa fa-shopping-cart ms-2"></i>
                            <a class="small fw-medium" href="https://wa.me/6282279666651?text=Hai!%20Saya%20ingin%20memesan%20produk%20ini!">Beli Sekarang</a>
                        </div>
                    </div>
                </div>
               <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item rounded overflow-hidden">
                        <img class="img-fluid" src="img/susustroberi.jpg" alt="">
                        <div class="position-relative p-4 pt-0">
                            <h4 class="mb-3 mt-3">Susu Stroberi</h4>
                            <p>Susu segar rasa stroberi yang mengalami  pasteurisasi dengan kualitas terbaik</p>
                            <p style="font-weight: 700; margin-bottom: 2px;">Rp 35.000 / L</p>
                            <i class="fa fa-shopping-cart ms-2"></i>
                            <a class="small fw-medium" href="https://wa.me/6282279666651?text=Hai!%20Saya%20ingin%20memesan%20produk%20ini!">Beli Sekarang</a>
                        </div>
                    </div>
                </div>
               <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item rounded overflow-hidden">
                        <img class="img-fluid" src="img/susucokelat.jpg" alt="">
                        <div class="position-relative p-4 pt-0">
                            <h4 class="mb-3 mt-3">Susu Cokelat</h4>
                            <p>Susu segar dipadukan dengan cokelat yang mengalami  pasteurisasi dengan kualitas terbaik</p>
                            <p style="font-weight: 700; margin-bottom: 2px;">Rp 35.000 / L</p>
                            <i class="fa fa-shopping-cart ms-2"></i>
                            <a class="small fw-medium" href="https://wa.me/6282279666651?text=Hai!%20Saya%20ingin%20memesan%20produk%20ini!">Beli Sekarang</a>
                        </div>
                    </div>
                </div>
               <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item rounded overflow-hidden">
                        <img class="img-fluid" src="img/susumoka.jpg" alt="">
                        <div class="position-relative p-4 pt-0">
                            <h4 class="mb-3 mt-3">Susu Mocca</h4>
                            <p>Susu segar yang dipadukan dengan Kopi dan Cokelat dengan kualitas terbaik</p>
                            <p style="font-weight: 700; margin-bottom: 2px;">Rp 35.000 / L</p>
                            <i class="fa fa-shopping-cart ms-2"></i>
                            <a class="small fw-medium" href="https://wa.me/6282279666651?text=Hai!%20Saya%20ingin%20memesan%20produk%20ini!">Beli Sekarang</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item rounded overflow-hidden">
                        <img class="img-fluid" src="img/keju.jpg" alt="">
                        <div class="position-relative p-4 pt-0">
                            <h4 class="mb-3 mt-3">Keju</h4>
                            <p>Keju dengan cita rasa yang khas hasil olahan susu Kerbau Morrah dengan kualitas terbaik</p>
                            <p style="font-weight: 700; margin-bottom: 2px;">Rp 650.000 /Kg</p>
                            <i class="fa fa-shopping-cart ms-2"></i>
                            <a class="small fw-medium" href="https://wa.me/6282279666651?text=Hai!%20Saya%20ingin%20memesan%20produk%20ini!">Beli Sekarang</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Product End -->


    <!-- Team Start -->
    <!-- <div class="container-xxl py-5" id="section4">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <h6 class="text-primary">Team Member</h6>
                <h1 class="mb-4">Meet Our Team Members</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item rounded overflow-hidden">
                        <div class="d-flex">
                            <img class="img-fluid w-75" src="a" alt="">
                            <div class="team-social w-25">
                                <a class="btn btn-lg-square btn-outline-primary rounded-circle mt-3" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-lg-square btn-outline-primary rounded-circle mt-3" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-lg-square btn-outline-primary rounded-circle mt-3" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="p-4">
                            <h5>Full Name</h5>
                            <span>Designation</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="team-item rounded overflow-hidden">
                        <div class="d-flex">
                            <img class="img-fluid w-75" src="b" alt="">
                            <div class="team-social w-25">
                                <a class="btn btn-lg-square btn-outline-primary rounded-circle mt-3" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-lg-square btn-outline-primary rounded-circle mt-3" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-lg-square btn-outline-primary rounded-circle mt-3" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="p-4">
                            <h5>Full Name</h5>
                            <span>Designation</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="team-item rounded overflow-hidden">
                        <div class="d-flex">
                            <img class="img-fluid w-75" src="c" alt="">
                            <div class="team-social w-25">
                                <a class="btn btn-lg-square btn-outline-primary rounded-circle mt-3" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-lg-square btn-outline-primary rounded-circle mt-3" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-lg-square btn-outline-primary rounded-circle mt-3" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="p-4">
                            <h5>Full Name</h5>
                            <span>Designation</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Team End -->


    <!-- Testimonial Start -->
    <div class="container-xxl py-5" id="section3">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <h6 class="text-primary">Testimonial</h6>
                <h1 class="mb-4">What People Say!</h1>
            </div>
            <div class="owl-carousel testimonial-carousel mx-auto wow fadeInUp" data-wow-delay="0.1s">
                <div class="testimonial-item text-center">
                    <div class="testimonial position-relative">
                        <div class="btn-square bg-primary rounded-circle">
                            <i class="fa fa-quote-left text-white"></i>
                        </div>
                    </div>
                    <div class="testimonial-text text-center rounded p-4">
                        <i class="fa fa-quote-left text-white"></i>
                        <p>Susu Murni Olahan Morrah Farm memiliki citarasa yang khas, sehingga menambah rasa ke minuman yang di racik, terlebih ke racikan kopi khas Piltik
                        </p>
                        <h5 class="mb-1">Piltik Coffee Siborongborong</h5>
                        <span class="fst-italic">Kafe</span>
                    </div>
                </div>
                <div class="testimonial-item text-center">
                    <div class="testimonial position-relative">
                        <div class="btn-square bg-primary rounded-circle">
                            <i class="fa fa-quote-left text-white"></i>
                        </div>
                    </div>
                    <div class="testimonial-text text-center rounded p-4">
                        <i class="fa fa-quote-left text-white"></i>
                        <p>Keju olahan dari Morrah Farm benar-benar punya rasa yang khas. Kualitas keju terbaik dan bukan abal abal</p>
                        <h5 class="mb-1">Michelle M</h5>
                        <span class="fst-italic">Mahasiswa</span>
                    </div>
                </div>
                <div class="testimonial-item text-center">
                    <div class="testimonial position-relative">
                        <div class="btn-square bg-primary rounded-circle">
                            <i class="fa fa-quote-left text-white"></i>
                        </div>
                    </div>
                    <div class="testimonial-text text-center rounded p-4">
                        <i class="fa fa-quote-left text-white"></i>
                        <p>Pelanggan di kopi lonceng sangat suka susu dari Morrah Farm. Selain dijadikan campuran untuk kopi, susu dari Morrah Farm juga enak dinikmati apalagi saat dingin</p>
                        <h5 class="mb-1">Kopi Lonceng Tarutung</h5>
                        <span class="fst-italic">Sopo Kreatif Tarutung</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->


    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-body footer mt-5 pt-5 wow fadeIn" data-wow-delay="0.1s" id="footer">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-5 col-md-6">
                    <h5 class="text-white mb-4">Alamat</h5>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i> Desa Bahal Batu I, Siborong-borong </p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>0856-6814-0378 (Ika Diana Br. Sembiring)</p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-square btn-outline-light btn-social" href="https://www.facebook.com/morrahfarm"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-square btn-outline-light btn-social" href="https://www.instagram.com/morrahfarm/"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                
                <div class="col-lg-5 col-md-6">
                    <h5 class="text-white mb-4">Gallery</h5>
                    <div class="row g-2">
                        <div class="col-4">
                            <img class="img-fluid rounded w-75 h-75" src="img/susu.jpeg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-75 h-75" src="img/susu1.jpeg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-75 h-75" src="img/susu2.jpeg" alt="">
                        </div>
                        <div class="col-4">
                           <img class="img-fluid rounded w-75 h-75" src="img/susu3.jpeg" alt="">
                        </div>
                        <div class="col-4">
                           <img class="img-fluid rounded w-75 h-75" src="img/kerbau1.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-75 h-75" src="img/kerbau2.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">192406061 Tugas Akhir</a>, All Right Reserved.
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>


    
</body>

</html>